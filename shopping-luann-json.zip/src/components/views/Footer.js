import React from 'react';

export default () => {
  return(
    <footer className="section footer-classic context-dark bg-image">
      <div className=" shop-footer text-center py-3">made with Love by <a target="blank"
                                                                         href="/"> Thanhluandesign </a>.This project is open source, visit<a target="blank"
                                                       href="https://github.com/kelnguyen87/redux-shopping"> the
        repo</a></div>

      </footer>
  );
}
